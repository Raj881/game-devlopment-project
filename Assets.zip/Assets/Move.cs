using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Move : MonoBehaviour
{
    Rigidbody r1;
    float moveh;
    float movev;
    float j;
    public int speed=5;
    public Text scoreText;
    private int score = 0;
    public Text gameOver;
// Start is called before the first frame update
void Start()
{
r1 = GetComponent<Rigidbody>();

}

// Update is called once per frame
void Update()
{
  moveh = Input.GetAxis("Horizontal");
  movev = Input.GetAxis("Vertical");
  j = Input.GetAxis("Jump");
  Vector3 m = new Vector3(moveh,j,movev);
  r1.AddForce(m*speed);
}

void OnTriggerEnter(Collider obj)
{
    if(obj.gameObject.CompareTag("enemy"))
    {
        score = score + 1;
        scoreText.text = "Score: " + score.ToString();
        Destroy(obj.gameObject);
        if(score == 10){
            gameOver.text = "You Won";
            Time.timeScale = 0f;
        }
    }

    if(obj.gameObject.CompareTag("spikeball")){
        gameOver.text = "Game Over";
        Time.timeScale = 0f;
    }
  
}
}
